import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { IPizza } from './pizza';
import { PizzaService } from './pizza.service';

@Component({
  templateUrl: './pizza-detail.component.html',
  styleUrls: ['./pizza-detail.component.css']
})
export class PizzaDetailComponent implements OnInit {
  pageTitle = 'Pizza Detail';
  errorMessage = '';
  pizza: IPizza | undefined;

  constructor(private route: ActivatedRoute,
    private router: Router,
    private pizzaService: PizzaService) {
  }

  ngOnInit() {
    const param = this.route.snapshot.paramMap.get('id');
    if (param) {
      const id = +param;
      this.getPizza(id);
    }
  }

  getPizza(id: number) {
    this.pizzaService.getPizza(id).subscribe(
      pizza => this.pizza = pizza,
      error => this.errorMessage = <any>error);
  }

  onBack(): void {
    this.router.navigate(['/pizzas']);
  }

  addToCart(pizza) {
    window.alert('Your pizza has been added to the cart!');
    this.pizzaService.addToCart(pizza);
    console.log("DONE");
  }

}
