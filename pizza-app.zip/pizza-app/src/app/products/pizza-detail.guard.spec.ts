import { TestBed, async, inject } from '@angular/core/testing';

import { PizzaDetailGuard } from './pizza-detail.guard';

describe('PizzaDetailGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PizzaDetailGuard]
    });
  });

  it('should ...', inject([PizzaDetailGuard], (guard: PizzaDetailGuard) => {
    expect(guard).toBeTruthy();
  }));
});
