import { Component, OnInit } from '@angular/core';

import { IPizza } from './pizza';
import { PizzaService } from './pizza.service';

@Component({
  templateUrl: './pizza-list.component.html',
  styleUrls: ['./pizza-list.component.css']
})
export class PizzaListComponent implements OnInit {
  pageTitle = 'Pizza List';
  imageWidth = 50;
  imageMargin = 2;
  showImage = false;
  errorMessage = '';

  _listFilter = '';
  get listFilter(): string {
    return this._listFilter;
  }
  set listFilter(value: string) {
    this._listFilter = value;
    this.filteredPizzas = this.listFilter ? this.performFilter(this.listFilter) : this.pizzas;
  }

  filteredPizzas: IPizza[] = [];
  pizzas: IPizza[] = [];

  constructor(private pizzaService: PizzaService) {

  }

  onRatingClicked(message: string): void {
    this.pageTitle = 'Pizza List: ' + message;
  }

  performFilter(filterBy: string): IPizza[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.pizzas.filter((pizza: IPizza) =>
      pizza.pizzaName.toLocaleLowerCase().indexOf(filterBy) !== -1);
  }

  toggleImage(): void {
    this.showImage = !this.showImage;
  }

  ngOnInit(): void {
    this.pizzaService.getPizzas().subscribe(
      pizzas => {
        this.pizzas = pizzas;
        this.filteredPizzas = this.pizzas;
      },
      error => this.errorMessage = <any>error
    );
  }
}
