import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { PizzaListComponent } from './pizza-list.component';
import { PizzaDetailComponent } from './pizza-detail.component';
import { ConvertToSpacesPipe } from '../shared/convert-to-spaces.pipe';
import { PizzaDetailGuard } from './pizza-detail.guard';
import { SharedModule } from '../shared/shared.module';
import { CartComponent } from '../cart/cart.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'pizzas', component: PizzaListComponent },
      {
        path: 'pizzas/:id',
        canActivate: [PizzaDetailGuard],
        component: PizzaDetailComponent,
        
      },
      { path: 'cart', component: CartComponent }
    ]),
    SharedModule
  ],
  declarations: [
    PizzaListComponent,
    PizzaDetailComponent,
    ConvertToSpacesPipe,
    CartComponent
  ]
})
export class PizzaModule { }
