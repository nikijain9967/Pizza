import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';

import { IPizza } from './pizza';

@Injectable({
  providedIn: 'root'
})
export class PizzaService {
  pizzas=[];
  private pizzaUrl = 'api/products/products.json';

  constructor(private http: HttpClient) { }

  getPizzas(): Observable<IPizza[]> {
    return this.http.get<IPizza[]>(this.pizzaUrl).pipe(
      tap(data => console.log('All: ' + JSON.stringify(data))),
      catchError(this.handleError)
    );
  }

  getPizza(id: number): Observable<IPizza | undefined> {
    return this.getPizzas().pipe(
      map((pizzas: IPizza[]) => pizzas.find(p => p.pizzaId === id))
    );
  }

  public addToCart(pizza){
    this.pizzas.push(pizza);
  }
  getCartPizzas() {
    return this.pizzas;
  }

  private handleError(err: HttpErrorResponse) {
    // in a real world app, we may send the server to some remote logging infrastructure
    // instead of just logging it to the console
    let errorMessage = '';
    if (err.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      errorMessage = `An error occurred: ${err.error.message}`;
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
    }
    console.error(errorMessage);
    return throwError(errorMessage);
  }
}
