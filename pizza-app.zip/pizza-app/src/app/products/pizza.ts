export interface IPizza {
  pizzaId: number;
  pizzaName: string;
  pizzaCode: string;
  releaseDate: string;
  price: number;
  description: string;
  starRating: number;
  imageUrl: string;
}

